package assignments;
/*
 * Launch chrome browser
 * navigate to http://newtours.demoaut.com/
 * click on Register link
 * fill the form except country
 * and click on submit
 */
public class MercuryToursAssignment {

}
