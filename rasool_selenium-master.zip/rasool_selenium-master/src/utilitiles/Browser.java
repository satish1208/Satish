package utilitiles;

public enum Browser {
	CHROME, FIREFOX;

}
