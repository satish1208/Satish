package polymorphism;

public class RTPolyParent {
	
	public void add(String a, String b) {
		System.out.println(a+b);
	}

}
