package polymorphism;

public class ChildOne extends RTPolyParent{

}
