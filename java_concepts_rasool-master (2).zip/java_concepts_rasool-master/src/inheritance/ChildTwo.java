package inheritance;

public class ChildTwo extends Parent{
	
	public void methodFour() {
		System.out.println("ChildTwo class method four");
	}

}
