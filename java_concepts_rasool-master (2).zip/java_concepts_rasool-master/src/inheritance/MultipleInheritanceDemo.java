package inheritance;

//public class MultipleInheritanceDemo extends ChildOne, ChildTwo{
//	
//
//}
