package inheritance;

public class SubChild extends ChildOne{

	public void methodThree() {
		System.out.println("sub child class method three");
	}
}
