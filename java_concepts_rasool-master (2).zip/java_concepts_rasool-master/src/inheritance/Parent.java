package inheritance;

public class Parent {
	
//	public Parent() {
//		System.out.println("Parent class object created");
//	}
	
	public void methodOne() {
		System.out.println("Parent class method one");
	}

}
