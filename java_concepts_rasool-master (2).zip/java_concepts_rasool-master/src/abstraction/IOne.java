package abstraction;

public interface IOne {
	
	void iOneMethod();

}
