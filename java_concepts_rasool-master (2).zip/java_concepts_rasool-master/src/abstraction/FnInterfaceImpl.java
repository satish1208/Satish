package abstraction;

public class FnInterfaceImpl implements FnInterfaceOne{

	@Override
	public void methodOne() {
		System.out.println("method one of FnInterfaceImpl");
	}
	
	

}
