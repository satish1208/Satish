package abstraction;

public class AbstractClassImpl extends AbstractClass{

	@Override
	public void methodTwo() {
		System.out.println("method two implementation in child class");
	}

	@Override
	public void methodThree() {
		System.out.println("method three implementation in child class");
	}
	
	
	
	
	
	
	

}
