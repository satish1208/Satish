package abstraction;
@FunctionalInterface
public interface FnIntefaceThree {
	
	int add(int a, int b);

}
