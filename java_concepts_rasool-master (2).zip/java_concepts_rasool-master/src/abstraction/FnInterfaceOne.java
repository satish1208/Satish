package abstraction;

@FunctionalInterface
public interface FnInterfaceOne {
	
	void methodOne();
	

}
