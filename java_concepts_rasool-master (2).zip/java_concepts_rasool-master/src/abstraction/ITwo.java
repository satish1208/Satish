package abstraction;

public interface ITwo {
	
	void iTwoMethod();

}
