package abstraction;

@FunctionalInterface
public interface FnInterfaceTwo {
	void add(int a, String b);
}
