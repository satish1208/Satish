package basics;
//single line comment

/*
 * Comments are lines of code which will not execute
 * There are 3 Type of comments in Java
 * single line 
 * multiline
 * documentation comments
 */

/**
 * This class explains how to write comments in Java
 */

public class CommentsDemo {

}
