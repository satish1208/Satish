package basics;

public class InstanceVsStatic {
	
	String name;
	
	static String institueName;
	
	
	public void display() {
		System.out.println("name = "+name);
		System.out.println("institue name "+institueName);
	}

}
