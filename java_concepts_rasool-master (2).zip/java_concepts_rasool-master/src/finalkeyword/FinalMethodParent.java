package finalkeyword;

public class FinalMethodParent {
	
	public void methodOne() {
		System.out.println("parent class method one");
	}
	
	public final void methodTwo() {
		System.out.println("parent class final method two");
	}

}
