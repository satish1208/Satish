package finalkeyword;

public class FinalMethodChild extends FinalMethodParent{
	
	@Override
	public void methodOne() {
		System.out.println("child class method one");
	}
	
	
//	@Override
//	public void methodTwo() {
//		
//	}

}
