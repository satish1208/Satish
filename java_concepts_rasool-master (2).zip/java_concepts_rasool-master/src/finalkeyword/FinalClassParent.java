package finalkeyword;

public class FinalClassParent {

}
