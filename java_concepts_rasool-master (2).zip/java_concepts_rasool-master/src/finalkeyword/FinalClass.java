package finalkeyword;

public final class FinalClass extends FinalClassParent{

}
